<?php 
return [
  'previous' => 'previous',
  'next' => 'próxima',
];