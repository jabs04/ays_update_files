<?php 
return [
  'previous' => 'vorig',
  'next' => 'De volgende',
];