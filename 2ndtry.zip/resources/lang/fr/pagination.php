<?php 
return [
  'previous' => 'précédente',
  'next' => 'suivante',
];