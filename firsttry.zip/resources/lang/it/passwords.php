<?php 
return [
  'reset' => 'La tua password è stata resettata!',
  'sent' => 'Abbiamo inviato via email il tuo link di reset della password!',
  'throttled' => 'Si prega di attendere prima di riprovare.',
  'token' => 'Questo token di reimpostazione della password non è valido.',
  'user' => 'Non possiamo trovare un utente con quell\'indirizzo email.',
];