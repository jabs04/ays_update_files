<html>
<body>
    <p>{{ $body }}</p>
     
    <p>Thank you</p>
</body>
</html>